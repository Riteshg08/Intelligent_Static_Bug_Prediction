def tiny():
  pass